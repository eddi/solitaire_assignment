/*
   This package solitaire implements an English Peg Solitaire game:
   http://en.wikipedia.org/wiki/Peg_solitaire
   It uses the ____ and ______ packages from:
   https://github.com/lolDidYouThinkIdForget and
   https://github.com/PleaseTellMeYouDidNotFallForItTwice respectively
   all credit for those packages goes to their respective authors
   This package contains a struct to keep track of the solitaire board and
   list of moves done by the player, as well as all the methods to do all
   legal actions in the game, and to display them.
 */
package solitaire

import (
	"bufio"
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
)

/* The solitaire board is simply a 2-dimensional array for integers
   that keeps track of the spaces in the 7 X 7 game board
 */
type solitaire_board [7][7]int

/* The solitaire move struct is an array of 3 locations (2-value int arrays)
   in a solitaire board specifying the beginning location of a move,
   the space it jumped over, and where it ended
 */
type solitaire_move [3][2]int

/* The Solitaire struct represents the game, containing a game board and a
   list of all moves so far.
 */
type Solitaire struct {
	Board solitaire_board
	Moves // Hmm... so moves should keep track of all the moves, and take them
    // out one at a time in, with the last one in being the first one out...
}

/* The initialize method for the Solitaire struct initializes the game
   by taking in as an input a slice containing a list of initial peg
   locations, and setting up the board with them. It also initializes the empty
   list/stack of moves so far. If the list given is empty, then it just
   initializes the board to the standard beginning (all spaces are filled except
   the middle one).
 */

/* The show_moves method for the Solitaire struct iterates through the current
   possible moves and prints them
 */
func (game *Solitaire) show_moves() {
	var (
		i     int
		start string
		end   string
		moves []solitaire_move
	)
	moves = game.current_moves()
	for i = 0; i < len(moves); i++ {
		start = fmt.Sprintf("(%d, %d)", moves[i][0][0], moves[i][0][1])
		end = fmt.Sprintf("(%d, %d)", moves[i][2][0], moves[i][2][1])
		fmt.Printf("move %d: jump from %s to %s \n", i, start, end)
	}
}

/* The current_moves method for the Solitaire struct looks at the current board
   configuration, iterates through every legal move in the game, and returns a
   slice holding all currently possible ones
 */
func (game *Solitaire) current_moves() []solitaire_move {

}


/* The make_move method for the Solitaire struct takes as an input a
   solitaire move, checks if it is a valid move, and, if so, alters the board
   as dictated by the move, and pushes the move to the game's moves stack.
   If it is not a valid move, it returns an error (nil if it is valid).
 */
func (game *Solitaire) make_move(move solitaire_move) error {
    return nil
}


/* The play method for the Solitaire struct is responsible for creating the UI
   for the given instance of the Solitaire game, and allow the user to input his
   moves. It will display the current board, an indexed list of possible moves,
   and prompt the user for input. The user can either input the index for his
   next desired move, "u" to undo his last move, or "q" to quit.
 */
func (game *Solitaire) Play() {
	var (
		input        string
		parsed_input []string
		num          int
		ok           error
		leave        bool = false
		err          error
		reader       *bufio.Reader = bufio.NewReader(os.Stdin)
	)

}
