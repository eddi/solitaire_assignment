package main

import (
	"github.com/eddi/solitaire/game"
)

func main() {
	var (
		game *solitaire.Solitaire = new(solitaire.Solitaire)
	)
	game.Initialize(nil)
	game.Play()
}
